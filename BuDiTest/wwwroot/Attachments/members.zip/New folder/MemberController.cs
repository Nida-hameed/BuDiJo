﻿using FormTask.Data;
using FormTask.Models;
using FormTask.Models.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FormTask.Controllers
{
    public class MemberController : Controller
    {
        private readonly ApplicationDbContext _db;
        public MemberController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            IEnumerable<Member> objMemberList = _db.Members;
            return View(objMemberList);
        }
        //GET
        //public IActionResult Create()
        //{

        //    return View();
        //}

        ////POST
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Create(Member obj)
        //{

        //   if(ModelState.IsValid)
        //    { 
        //    _db.Members.Add(obj);
        //        _db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(obj);

        //}


        ////GET
        //public IActionResult Edit(int? id)
        //{


        //    if (id == null || id == 0)
        //    {
        //        return NotFound();
        //    }
        //    // var CategoryFromDb = _db.Categories.Find(id);
        //    var MembersFromDbFirst = _db.Members.FirstOrDefault(u => u.Id == id);
        //    //var categoryFromDbSingle = _db.Categories.SingleOrDefault(u => u.id == id);

        //    if (MembersFromDbFirst == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(MembersFromDbFirst);
        //}
        ////POST
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Edit(Member obj)
        //{

        //    if (ModelState.IsValid)
        //    {
        //        _db.Members.Update(obj);
        //        _db.SaveChanges();
        //        TempData["success"] = "Member details Updated Successfully";
        //        return RedirectToAction("Index");
        //    }
        //    return View(obj);

        //}


        public IActionResult UpSert(int? id)
        {
            MemberVM memberVM = new()
            {
                Member = new(),
                MemberCategory = _db.Members.ToList().Select(i => new SelectListItem
                {
                    Text = i.Name,
                    Value = i.Id.ToString()
                }),

                //BankAccount = db.BankAccount.ToList().Select(i => new SelectListItem
                //{
                //    Text = i.Name,
                //    Value = i.Id.ToString()
                //}),
            };
            if (id == null || id == 0)
            {
                //Create member
                NotFound();
            }
            else
            {
                //Edit member
                memberVM.Member = _db.Members.FirstOrDefault(x => x.Id == id);
            }
            return View(memberVM);
        }


        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpSert(MemberVM obj)
        {
            if (obj.Member.Id == 0)
            {
                Random random = new Random();
                int code = random.Next(1001, 9999);
                obj.Member.InvoiceNo = "INC-" + code;
                obj.Member.PaymentType = "Credit";
                _db.Members.Add(obj.Member);
            }
            else
            {
                _db.Members.Update(obj.Member);
            }

            _db.SaveChanges();
            TempData["success"] = "Donation Added successfully!";
            return RedirectToAction("Index");
        }




        //GET

        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                NotFound();
            }
            var obj = _db.Members.FirstOrDefault(c => c.Id == id);
            if (obj == null)
            {
                NotFound();
            }
            return View(obj);
        }
        //POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePost(int? id)
        {
            var obj = _db.Members.FirstOrDefault(c => c.Id == id);
            if (obj == null)
            {
                NotFound();
            }
            _db.Members.Remove(obj);
            _db.SaveChanges();
            TempData["success"] = "Record deleted successfully!";
            return RedirectToAction("Index");
        }
        //// GET: Donation/Invoice/5
        public async Task<IActionResult> Invoice(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _db.Members.FindAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }


    }
}
