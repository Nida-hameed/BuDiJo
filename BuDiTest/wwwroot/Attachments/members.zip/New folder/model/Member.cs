﻿using System.ComponentModel.DataAnnotations;

namespace FormTask.Models
{
    public class Member
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Display(Name ="Father Name")]
        public string FatherName { get; set; }
        public double Fee { get; set; }
        [Display(Name = "Fee Type")]
        public string FeeType { get; set; }
        [Display(Name = "Account Type")]
        public string AccountType { get; set; }
        [Display(Name = "Fee Month")]
        public string FeeMonth { get; set; }
        [Display(Name = "Invoice No")]
        public string InvoiceNo { get; set; }

        public DateTime Date { get; set; }
        [Display(Name = "Phone No")]
        public string PhoneNumber { get; set; }
        [Display(Name = "Amount Type")]
        public string AmountType { get; set; }
        public int Tax { get; set; }
        public string Designation { get; set; }
        public string City { get; set; }
        public string Level { get; set; }
        public string PaymentType { get; set; }
        public double Total { get; set; }
    }
}
