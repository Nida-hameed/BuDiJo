﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FormTask.Models.ViewModel
{
    public class MemberVM
    {
        public Member Member { get; set; }
        [ValidateNever]
        public IEnumerable<SelectListItem> FeeTypeList { get; set; }
        [ValidateNever]
        public IEnumerable<SelectListItem> AmountTypeList { get; set; }
        [ValidateNever]
        public IEnumerable<SelectListItem> AccountTypeList { get; set; }
        [ValidateNever]
        public IEnumerable<SelectListItem> FeeMonthList{ get; set; }
        public IEnumerable<SelectListItem> MemberCategory { get; set; }
    }
}
